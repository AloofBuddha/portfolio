# Author

Benjamin Cohen

# Examples
- permutations - a simple program that returns the list of permutations of a given list. Written in Haskell, written 2016
- Raytracer - excerpts from a Raytracer built in C++, written 2014
- Vera - excerpts from a game project built in Unity using C#, written 2014
- web development - a server with a small RESTful API and a client that calls the API and displays the info using React as the rendering engine. Written in JavaScript, 2020